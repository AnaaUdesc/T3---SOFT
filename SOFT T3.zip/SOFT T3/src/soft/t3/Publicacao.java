
package soft.t3;

import java.util.ArrayList;

/**
 *
 * @author an4cb
 */
public class Publicacao {

    private String idPubli;
    private String texto;
    private Usuario usuario;
    private Integer contDenuncia;
    //omitimos data da publicaçao,likes  e deslikes pois não serao uteis para o trabalho

    public Publicacao(String idPubli, String texto, Usuario usuario, Integer contDenuncia) {
        this.idPubli = idPubli;
        this.texto = texto;
        this.usuario = usuario;
        this.contDenuncia = contDenuncia;

    }
    

    public String getIdPubli() {
        return idPubli;
    }

    public void setIdPubli(String idPubli) {
        this.idPubli = idPubli;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Integer getContDenuncia() {
        return contDenuncia;
    }

    public void setContDenuncia(Integer contDenuncia) {
        this.contDenuncia = contDenuncia;
    }
    
    public void decrementDenuncia() {
        this.contDenuncia--;
    }
    
    public void incrementaDenuncia() {
        this.contDenuncia++;
    }

}
