
package soft.t3;

/**
 *
 * @author an4cb
 */
public class Pergunta extends Publicacao {

    private Regiao regiao;

    public Pergunta(String idPubli, String texto, Usuario usuario, Integer contDenuncia, Regiao regiao) {
        super(idPubli, texto, usuario, contDenuncia);
        this.regiao = regiao;
    }

    public Regiao getRegiao() {
        return regiao;
    }

    public void setRegiao(Regiao regiao) {
        this.regiao = regiao;
    }

}
