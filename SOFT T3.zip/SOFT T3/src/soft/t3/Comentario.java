
package soft.t3;

/**
 *
 * @author an4cb
 */
public class Comentario extends Publicacao {

    private Usuario mencao; // comentario pode ou nao mencionar algum outro usuario com @ por exemplo
    private Publicacao publicacaoAssociada; // um comentario sempre comenta alguma outra publicaçao

    public Comentario(String idPubli, String texto, Usuario usuario, Integer contDenuncia, Publicacao publicacaoAssociada) {
        super(idPubli, texto, usuario, contDenuncia);
        this.publicacaoAssociada = this.publicacaoAssociada;
    }

    public Comentario(String idPubli, String texto, Usuario usuario, Integer contDenuncia, Publicacao publicacaoAssociada, Usuario mencao) {
        super(idPubli, texto, usuario, contDenuncia);
        this.publicacaoAssociada = publicacaoAssociada;
        this.mencao = mencao;
    }

    public Usuario getMencao() {
        return mencao;
    }

    public void setMencao(Usuario mencao) {
        this.mencao = mencao;
    }

    public Publicacao getPublicacaoAssociada() {
        return publicacaoAssociada;
    }

    public void setPublicacaoAssociada(Publicacao publicacaoAssociada) {
        this.publicacaoAssociada = publicacaoAssociada;
    }

}
