

// para o trabalho de SOFT nao usamos um Banco de dados, 
//entao optamos por usar listas como forma de armazenar as informaçoes

package soft.t3;

import java.util.ArrayList;

/**
 *
 * @author an4cb
 */
public class Banco {

    private final ArrayList<Publicacao> publicacoes;
    private final ArrayList<Usuario> usuarios;
    private final ArrayList<Denuncia> denuncias;

    public Banco() {
        publicacoes = new ArrayList<>();
        usuarios = new ArrayList<>();
        denuncias = new ArrayList<>();
    }

  
    public ArrayList<Publicacao> getPublicacoes() {
        return publicacoes;
    }
    
    public ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }

    public void addUsuario(Usuario user, Banco ban) {
        usuarios.add(user);
    }

    
     public ArrayList<Denuncia> getDenuncias() {
        return denuncias;
    }


}
