
package soft.t3;

/**
 *
 * @author an4cb
 */
public class Resposta extends Publicacao {

    private String gif; // deveria ser um file, porem não há necessidade de trabalhar com arquivos do tipo file aqui, pois nao influencia no trabalho, apenas tornaria a intanciaçao mais trabalhosa.
    private Publicacao publicacaoAssociada;// uma resposta sempre responde uma pergunta

    public Resposta(String idPubli, String texto, Usuario usuario, Integer contDenuncia, Publicacao publicacaoAssociada, String gif) {
        super(idPubli, texto, usuario, contDenuncia);
        this.gif = gif;
        this.publicacaoAssociada = publicacaoAssociada;
    }

    public Publicacao getPublicacaoAssociada() {
        return publicacaoAssociada;
    }

    public void setPublicacaoAssociada(Publicacao publicacaoAssociada) {
        this.publicacaoAssociada = publicacaoAssociada;
    }

    public String getGif() {
        return gif;
    }

    public void setGif(String gif) {
        this.gif = gif;
    }

}
