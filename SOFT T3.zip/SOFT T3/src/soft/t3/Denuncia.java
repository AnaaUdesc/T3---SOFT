/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soft.t3;

/**
 *
 * @author an4cb
 */
public class Denuncia {

    private String idDenuncia;
    private Publicacao publicacaoDenunciada;
    private Usuario UsuarioDenunciou;

    public Denuncia(String idDenuncia, Publicacao publicacaoDenunciada, Usuario UsuarioDenunciou) {
        this.idDenuncia = idDenuncia;
        this.publicacaoDenunciada = publicacaoDenunciada;
        this.UsuarioDenunciou = UsuarioDenunciou;

    }

    public String getIdDenuncia() {
        return idDenuncia;
    }

    public void setIdDenuncia(String idDenuncia) {
        this.idDenuncia = idDenuncia;
    }

    public Publicacao getPublicacaoDenunciada() {
        return publicacaoDenunciada;
    }

    public void setPublicacaoDenunciada(Publicacao publicacaoDenunciada) {
        this.publicacaoDenunciada = publicacaoDenunciada;
    }

    public Usuario getUsuarioDenunciou() {
        return UsuarioDenunciou;
    }

    public void setUsuarioDenunciou(Usuario UsuarioDenunciou) {
        this.UsuarioDenunciou = UsuarioDenunciou;
    }

}
