/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soft.t3;

/**
 *
 * @author an4cb
 */
public class Regiao {

    private String cidade;
    private String estado;

    public Regiao(String cidade, String estado) {
        this.cidade = cidade;
        this.estado = estado;

    }
    
    public Regiao () {
        this.cidade = null;
        this.estado = null;

    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

}
