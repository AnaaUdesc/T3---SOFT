
package soft.t3;

import java.util.ArrayList;

/**
 *
 * @author an4cb
 */
public class Usuario {

    private String idUser;
    private String nome;
    private String email;
    private String senha;
    private Regiao Regiao;
    private Integer contDenunciasUser;
    private Boolean isAdmin;

    public Usuario(String idUser, String nome, String email, String senha, Regiao Regiao, Integer contDenunciasUser, Boolean isAdmin) {
        this.idUser = idUser;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.Regiao = Regiao;
        this.contDenunciasUser = contDenunciasUser;
        this.isAdmin = isAdmin;
    }
    
     //Coloca a nova publicaçao no array de publicaçoes
    public void Publicar(Publicacao publi, Banco ban) { 
        ban.getPublicacoes().add(publi);
    }
    
     // Cria a denuncia, insere ela no array de denucnias e incrementa os contadores de denuncias do perfil do usuario e da publicaçao denunciada
    public Denuncia Denunciar(String idDenuncia, Publicacao publicacaoDenunciada, Usuario UsuarioDenunciou,Banco ban) {
        Denuncia d = new Denuncia(idDenuncia,publicacaoDenunciada,UsuarioDenunciou);
        d.getPublicacaoDenunciada().incrementaDenuncia();
        d.getPublicacaoDenunciada().getUsuario().incrementaDenunciasUser();
        ban.getDenuncias().add(d);
        return d;
    }
    
    //Quando uma publicaçao é denunciada e viola as diretrizes do sistema, ela deve ser excluida, esse metodo é uma subdivisão do Caso de Uso Adminsitrar
    public void deletarPublicacao(Denuncia denuncia, Usuario usuarioLogado,Banco ban) throws Exception {
        if (usuarioLogado.getIsAdmin() == true) {
            Publicacao pub = denuncia.getPublicacaoDenunciada();
            for (int i = 0; i < ban.getPublicacoes().size(); i++) {
                if (ban.getPublicacoes().get(i).equals(pub)) {
                    ban.getPublicacoes().remove(i);
                }
            }

        } else {
            throw new Exception("Usuario não é adimistrador.");

        }

    }
    
    //Quando uma publicaçao é denunciada e não viola as diretrizes do sistema, a denuncia deve ser desfeita, esse metodo é uma subdivisão do Caso de Uso Adminsitrar
    public void deletarDenuncia(Denuncia denuncia, Usuario usuarioLogado, Banco ban) throws Exception {   
        if (usuarioLogado.getIsAdmin() == true) {
            Publicacao pub = denuncia.getPublicacaoDenunciada();
            for (int i = 0; i < ban.getPublicacoes().size(); i++) {
                if (ban.getPublicacoes().get(i).getIdPubli().equals(pub.getIdPubli())) {
                    ban.getPublicacoes().get(i).decrementDenuncia();
                    ban.getPublicacoes().get(i).getUsuario().decrementDenunciasUser();
                }
            }

            for (int i = 0; i < ban.getDenuncias().size(); i++) {
                if (ban.getDenuncias().get(i).getIdDenuncia().equals(denuncia.getIdDenuncia())) {
                    ban.getDenuncias().remove(i);
                }
            }

        } else {
            throw new Exception("Usuario não é adimistrador.");

        }

    }
    
     
    //Esse metodo busca por palavras no sistema, usando Estado e Cidade como filtros.
    //Basicamente começo selecioando apenas as publicaçoes que são do tipo pergunta, pois apenas essas possuem estado e cidade como atributos.
    //Coloco todas as perguntas em um array, e nas compaçoes seguintes vou tirando do array as pergunats que não correspondem ao meu filtro de estado e cidade.
    //Apenas duas possibilidade geram exceçoes: buscar por cidade sem inserir estado e buscar uma palavra que não existe
    public ArrayList<Pergunta> Pesquisar(String palavra, Regiao regiao,Banco ban) throws Exception {

        ArrayList<Pergunta> publicacoesSelecionadas = new ArrayList<>();

        for (int i = 0; i < ban.getPublicacoes().size(); i++) {
            if (ban.getPublicacoes().get(i) instanceof Pergunta) {
                publicacoesSelecionadas.add((Pergunta) ban.getPublicacoes().get(i));
            }
        }

        if (palavra != null) {
            for (int i = 0; i < publicacoesSelecionadas.size(); i++) {
                if (!(publicacoesSelecionadas.get(i).getTexto().toLowerCase().contains(palavra.toLowerCase()))) {
                    publicacoesSelecionadas.remove(publicacoesSelecionadas.get(i));
                }

            }
            if (publicacoesSelecionadas.isEmpty()) {
                throw new Exception("A palavra ainda não foi mencionada no sistema.");
            }

            if (regiao.getEstado() != null) {
                for (int i = 0; i < publicacoesSelecionadas.size(); i++) {
                    if (!(publicacoesSelecionadas.get(i).getRegiao().getEstado().equals(regiao.getEstado()))) {
                        publicacoesSelecionadas.remove(publicacoesSelecionadas.get(i));
                    }
                }
            }
            if (regiao.getCidade() != null) {
                for (int i = 0; i < publicacoesSelecionadas.size(); i++) {
                    if (!(publicacoesSelecionadas.get(i).getRegiao().getCidade().equals(regiao.getCidade()))) {
                        publicacoesSelecionadas.remove(publicacoesSelecionadas.get(i));
                    }
                }
            }

        } else {
            if (regiao.getEstado() != null) {
                for (int i = 0; i < publicacoesSelecionadas.size(); i++) {
                    if (!(publicacoesSelecionadas.get(i).getRegiao().getEstado().equals(regiao.getEstado()))) {
                        publicacoesSelecionadas.remove(publicacoesSelecionadas.get(i));
                    }

                }
            }
            if (regiao.getCidade() != null && regiao.getEstado() != null) {
                for (int i = 0; i < publicacoesSelecionadas.size(); i++) {
                    if (!(publicacoesSelecionadas.get(i).getRegiao().getCidade().equals(regiao.getCidade()))) {
                        publicacoesSelecionadas.remove(publicacoesSelecionadas.get(i));
                    }

                }
            
            }
            if (regiao.getCidade() != null && regiao.getEstado() == null) {
                throw new Exception("Não é possivel pesquisar sem um estado.");
            } else {
                if (regiao.getCidade() != null) {
                    for (int i = 0; i < publicacoesSelecionadas.size(); i++) {
                        if (!(publicacoesSelecionadas.get(i).getRegiao().getCidade().equals(regiao.getCidade()))) {
                            publicacoesSelecionadas.remove(publicacoesSelecionadas.get(i));
                        }
                    }

                }

            }

        }
        return publicacoesSelecionadas;
    }

    public String getIdUser() {
        return idUser;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Regiao getRegiao() {
        return Regiao;
    }

    public void setRegiao(Regiao Regiao) {
        this.Regiao = Regiao;
    }

    public Integer getContDenunciasUser() {
        return contDenunciasUser;
    }

    public void setContDenunciasUser(Integer contDenunciasUser) {
        this.contDenunciasUser = contDenunciasUser;
    }
    
    public void decrementDenunciasUser() {
        this.contDenunciasUser--;
    }
    
     public void incrementaDenunciasUser() {
        this.contDenunciasUser++;
    }

    public Boolean getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(Boolean isAdmin) {
        this.isAdmin = isAdmin;
    }
}
