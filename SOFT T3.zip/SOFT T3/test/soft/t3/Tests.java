
package soft.t3;

import java.util.ArrayList;
import java.util.Arrays;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author an4cb
 */
public class Tests {

    public Banco ban;

    public Pergunta per;
    public Resposta res;
    public Pergunta per2;
    public Pergunta per3;
    public Pergunta per4;
    public Pergunta per5;
    public Pergunta per6;
    public Comentario com;

    public Regiao reg1;
    public Regiao reg2;
    public Regiao reg3;

    public Usuario user1;
    public Usuario user2;

    public Tests() {
    }

    @Before
    public void setUp() {
        
        //Criando regioes 
        reg1 = new Regiao("Joinville", "Santa Catarina");
        reg2 = new Regiao("Posto Alegre", "Rio Grande do Sul");
        reg3 = new Regiao("Florianopolis", "Santa Catarina");

        //Usuarios para fazer publicaçoes
        user1 = new Usuario("000", "Joana", "joana@gmail.com", "12345", reg2, 0, false);
        user2 = new Usuario("001", "Tiago", "tiago@gmail.com", "54321", reg1, 0, false);

        //Criando perguntas, respostas e comentarios
        per = new Pergunta("000", "Como fala pai?", user1, 0, reg1);
        res = new Resposta("001", "rua fala-se assim:", user2, 0, per, "http/hgysadgao");
        per2 = new Pergunta("003", "Como fala rua?", user2, 0, reg1);
        per3 = new Pergunta("004", "Rua se fala como?", user1, 0, reg3);
        per4 = new Pergunta("005", "cabide se fala como?", user2, 0, reg3);
        per5 = new Pergunta("006", "rua fala-se assim:", user1, 0, reg3);
        per6 = new Pergunta("006", "fala-se assim:", user1, 0, reg2);
        com = new Comentario("007", "rua fala-se assim:", user1, 0, per3);

        //Colocando as publicaçoes em um array de publicaçoes
        ban = new Banco();
        user1.Publicar(per, ban);
        user2.Publicar(res, ban);
        user2.Publicar(per2, ban);
        user1.Publicar(per3, ban);
        user2.Publicar(per4, ban);
        user1.Publicar(per5, ban);
        user1.Publicar(per6, ban);
        user1.Publicar(com, ban);
    }


    @Test
    public void testPublicar() {  // verificar se 3 os novos objetos estão contidos na lista de publicaçoes

        ArrayList<Publicacao> publicacoes = ban.getPublicacoes();
  
        assertTrue(publicacoes.contains(per));
        assertTrue(publicacoes.contains(com));
        assertTrue(publicacoes.contains(res));

    }

    @Test
    public void testDenunciar() {

        ArrayList<Denuncia> denuncias = ban.getDenuncias();

        //Cria copia da publicaçao e alterando para saber se o teste vai gerar o resultado espeardo
        Publicacao perCopia = (Publicacao) per;
        perCopia.setContDenuncia(perCopia.getContDenuncia()+1);
        perCopia.getUsuario().setContDenunciasUser(perCopia.getUsuario().getContDenunciasUser()+1);

        
        Denuncia d1 = user1.Denunciar("0000", per, user1,ban);

        //testar se a nova denuncia esta contida no array de denuncias 
        assertTrue(denuncias.contains(d1));

        //testa se o metodo fez os incremnetos devidos nos contadores de denuncias
        assertTrue(d1.getPublicacaoDenunciada().getContDenuncia().equals(perCopia.getContDenuncia()));
        assertTrue(d1.getPublicacaoDenunciada().getUsuario().getContDenunciasUser().equals(perCopia.getUsuario().getContDenunciasUser()));

    }

    @Test
    public void testDeletarPublicacaoUserAdmin() throws Exception {

        user2.setIsAdmin(true);//tornando um dos usuarios já existentes em administrador

        Denuncia d2 = new Denuncia("0001", com, user2);// a publicacao denunciada foi o comentario 'com' 

        user1.deletarPublicacao(d2, user2, ban);

        ArrayList<Publicacao> publicacoes = ban.getPublicacoes();

        //testar se a publicaçao Denunciada não esta mais na lista de publicaçoes
        assertFalse(publicacoes.contains(d2.getPublicacaoDenunciada()));

    }

    @Test
    public void testDeletarPublicacaoUserNaoAdmin() throws Exception {

        Denuncia d1 = new Denuncia("0002", res, user2);

        try {
            user2.deletarPublicacao(d1, user1, ban); // user1 não é administrador
        } catch (Exception e) {
            assertEquals(e.getMessage(), "Usuario não é adimistrador.");
        }

    }

    @Test
    public void testDeletarDenunciaUserAdmin() throws Exception {

        user2.setIsAdmin(true);//tornando um dos usuarios já existentes em administrador

        Denuncia d2 = new Denuncia("0003", com, user1);

        //Cria copia da denuncia e decrementando contadores de denuncias para saber se o teste vai gerar o resultado espeardo
        Denuncia d2Copia = d2;
        d2.getPublicacaoDenunciada().setContDenuncia(d2Copia.getPublicacaoDenunciada().getContDenuncia()-1);
        d2.getPublicacaoDenunciada().getUsuario().setContDenunciasUser(d2Copia.getPublicacaoDenunciada().getUsuario().getContDenunciasUser()-1);

        user2.deletarDenuncia(d2, user2, ban);

        //testar se a denuncia nao esta mais na lista de denuncias
        assertFalse(ban.getDenuncias().contains(d2));
        //testar se os decrementos foram feitos corretamente
        assertTrue(d2.getPublicacaoDenunciada().getContDenuncia().equals(d2Copia.getPublicacaoDenunciada().getContDenuncia()));
        assertTrue(d2.getPublicacaoDenunciada().getUsuario().getContDenunciasUser().equals(d2Copia.getPublicacaoDenunciada().getUsuario().getContDenunciasUser()));

    }

    @Test
    public void testDeletarDenunciaUserNaoAdmin() throws Exception {

        Denuncia d1 = new Denuncia("0004", per, user2);

        try {
            user1.deletarDenuncia(d1, user1,ban);// user1 não é administrador
        } catch (Exception e) {
            assertEquals(e.getMessage(), "Usuario não é adimistrador.");
        }

    }

//    // Daqui em diante tentamos cobrir os casos possiveis de pesquisar
//    // Para pesquisar é preciso inserir a palavra de interesse, o Estado e a Cidade, que funcionam como filtros para pesquisa.
//    //
//    // Casos possiveis:
//    //
//    //1. Inserir os 3 campos corretamente:
//    //          retorno: Perguntas que mencionam a palavra, o estado e a cidade de interesse.
//    //
//    //2. Inserir somente a palavra.
//    //          retorno: Todas as perguntas que mencionam a palavra no sistema , indepedente do estado e cidade, ou seja, estados e cidades diversos.
//    //
//    //3. Inserir somente o estado.
//    //          retorno: Todas as perguntas que tem aquele estado como região.
//    //
//    //4. inserir somente a cidade.
//    //          retorno : Erro, pois existem no Brasil varias cidades com o mesmo nome.
//    //
//    //5. Inserir Estado e Cidade.
//    //          retorno: Todas as perguntas presentes no sistema que tem como regiao essa cidade e esse estado.
//    //
//    //6. Inserir Palavara e Cidade.
//    //          retorno: Erro, pois xistem no Brasil varias cidades com o mesmo nome, torna a busca inefiente.
//    //
//    //7. Inserir Palavra e Estado.
//    //          retorno: Todas as perguntas presentes no sistema que tem esse estado.
//    //
//    //8. Inserir palavra que ainda não existe no Sistema.
//    //          retorno: mensagem dizendo que a palavra ianda não existe no sistema.
//    
//    
//    //1. Inserir os 3 campos corretamente
    @Test
    public void testPesquisar1() throws Exception {


        ArrayList<Pergunta> listaSelecionados = user1.Pesquisar("rua", reg3, ban);

        //Criando array de controle para comparaçao
        ArrayList<Pergunta> listaEsperada = new ArrayList<>();
        listaEsperada.add(per3);
        listaEsperada.add(per5);

        //testando se o array retornado é igual ao esperado, independente da posicao no array
        assertTrue(listaSelecionados.size() == listaEsperada.size()
                && listaSelecionados.containsAll(listaEsperada)
                && listaEsperada.containsAll(listaSelecionados));

    }

    //2. Inserir somente a palavra.
    @Test
    public void testPesquisar2() throws Exception {

        Regiao regnull = new Regiao();
    
        ArrayList<Pergunta> listaSelecionados = user1.Pesquisar("rua", regnull,ban);

        //Criando array de controle para comparaçao
        ArrayList<Pergunta> listaEsperada = new ArrayList<>();
        listaEsperada.add(per3);
        listaEsperada.add(per2);
        listaEsperada.add(per5);

        //testando se o array retornado é igual ao esperado, independente da posicao no array
        assertTrue(listaSelecionados.size() == listaEsperada.size()
                && listaSelecionados.containsAll(listaEsperada)
                && listaEsperada.containsAll(listaSelecionados));

    }

    //3. Inserir somente o estado e palavra mas a cidade nula
    @Test
    public void testPesquisar3() throws Exception {

        Regiao regTeste = new Regiao(null, "Santa Catarina");
        
       
        ArrayList<Pergunta> listaSelecionados = user1.Pesquisar(null, regTeste,ban);

        //Criando array de controle para comparaçao
        ArrayList<Pergunta> listaEsperada = new ArrayList<>();
        listaEsperada.add(per);
        listaEsperada.add(per2);
        listaEsperada.add(per3);
        listaEsperada.add(per4);
        listaEsperada.add(per5);

        assertTrue(listaSelecionados.size() == listaEsperada.size()
                && listaSelecionados.containsAll(listaEsperada)
                && listaEsperada.containsAll(listaSelecionados));

    }

    //4. inserir somente a cidade. Palavra null e estado null
    @Test
    public void testPesquisar4() {
   
        Regiao regTeste = new Regiao("Joinville", null);

        try {
            user1.Pesquisar(null, regTeste,ban); //tentando encontrar apenas pela cidade
        } catch (Exception e) {
            assertEquals(e.getMessage(), "Não é possivel pesquisar sem um estado.");//Pois existem cidades com o mesmo nome em diferentes estados.
        }
    }

    //5. Inserir Estado e Cidade. Sem palavra
    @Test
    public void testPesquisar5() throws Exception {

    
 
        ArrayList<Pergunta> listaSelecionados = user1.Pesquisar(null, reg1,ban);

        //Criando array de controle para comparaçao
        ArrayList<Pergunta> listaEsperada = new ArrayList<>();
        listaEsperada.add(per);
        listaEsperada.add(per2);
       

        assertTrue(listaSelecionados.size() == listaEsperada.size()
                && listaSelecionados.containsAll(listaEsperada)
                && listaEsperada.containsAll(listaSelecionados));

    }

    //6. Inserir Palavara e Cidade. 
    @Test
    public void testPesquisar6() {

        Regiao regTeste = new Regiao("Joinville", null);

        try {
            user1.Pesquisar("rua", regTeste,ban); 
        } catch (Exception e) {
            assertEquals(e.getMessage(), "Não é possivel pesquisar sem um estado.");
        }

    }

    //7. Inserir Palavra e Estado.
    @Test
    public void testPesquisar7() throws Exception {

      Regiao regTeste = new Regiao(null, "Santa Catarina");

        ArrayList<Pergunta> listaSelecionados = user1.Pesquisar("RUA", regTeste, ban);

        //Criando array de controle para comparaçao
        ArrayList<Pergunta> listaEsperada = new ArrayList<>();
        listaEsperada.add(per2);
        listaEsperada.add(per3);
        listaEsperada.add(per5);

        assertTrue(listaSelecionados.size() == listaEsperada.size()
                && listaSelecionados.containsAll(listaEsperada)
                && listaEsperada.containsAll(listaSelecionados));

    }

    //8. Inserir palavra que ainda não existe no Sistema.
    @Test
    public void testPesquisar8() {

        try {
            user1.Pesquisar("Chocolate", reg1, ban); //regiao aleatória
        } catch (Exception e) {
            assertEquals(e.getMessage(), "A palavra ainda não foi mencionada no sistema.");
        }

    }
}
